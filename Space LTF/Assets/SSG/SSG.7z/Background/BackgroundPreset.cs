﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;


public class BackgroundPreset : ScriptableObject
{
    public Material MainMetarial;
    public Material ParticleMetarial;

}

