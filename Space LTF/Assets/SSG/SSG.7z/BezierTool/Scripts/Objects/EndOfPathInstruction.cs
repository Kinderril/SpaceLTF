﻿
	public enum EndOfPathInstruction {Loop, Reverse, Stop};

