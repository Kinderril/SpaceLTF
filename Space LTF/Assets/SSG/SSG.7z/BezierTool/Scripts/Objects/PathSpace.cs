﻿
	public enum PathSpace {xyz, xy, xz};

