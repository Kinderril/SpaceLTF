﻿using UnityEngine;
using System.Collections;

public class AIAsteroidData
{

    public Asteroid Object;
    public Vector3 Position;

    
}
