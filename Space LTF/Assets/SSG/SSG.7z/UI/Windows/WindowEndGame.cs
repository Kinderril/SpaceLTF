﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;


public class WindowEndGame : BaseWindow
{
    public override void Init()
    {
        base.Init();
    }

    public override void Dispose()
    {
        base.Dispose();
    }

    public void OnToNewGame()
    {
        WindowManager.Instance.OpenWindow(MainState.startNewGame);
    }

    
}

