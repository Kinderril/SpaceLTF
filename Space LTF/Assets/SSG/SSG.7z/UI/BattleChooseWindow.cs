﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


public class BattleChooseWindow : BaseWindow
{
    public override void Init()
    {

        base.Init();
    }

    public override void Close()
    {

        base.Close();
    }
}

