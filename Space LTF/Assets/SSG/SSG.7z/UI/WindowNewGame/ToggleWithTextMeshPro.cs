﻿using UnityEngine;
using System.Collections;
using TMPro;
using UnityEngine.UI;

public class ToggleWithTextMeshPro : MonoBehaviour
{
    public Toggle Toggle;
    public TextMeshProUGUI Field;
}
