﻿using UnityEngine;
using System.Collections;
using TMPro;

public class EndGameLose : MonoBehaviour
{

    public void Init()
    {

    }
}
