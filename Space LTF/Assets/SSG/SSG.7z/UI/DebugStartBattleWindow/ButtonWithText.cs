﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using UnityEngine.UI;


public class ButtonWithText : MonoBehaviour
{
    public Button Button;
    public Text Text;
    public Image Background;
}

