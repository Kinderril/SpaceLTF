﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;


public class WindowRepair : BaseWindow
{
    public Transform Layout;

    public override void Init()
    {
        base.Init();
    }
    


}

