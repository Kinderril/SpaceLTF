﻿using JetBrains.Annotations;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.EventSystems;

public class GlobalMapController : MonoBehaviour
{
    private GlobalMapCellObject[,] _allCells;
    private readonly List<SectorGlobalMapInfo> _allSectros = new List<SectorGlobalMapInfo>();

    private readonly Dictionary<GlobalMapCell, List<GlobalMapCellConnector>> _cellsWaysObjects
        = new Dictionary<GlobalMapCell, List<GlobalMapCellConnector>>();

    private readonly List<GlobalMapCellConnector> _connectors = new List<GlobalMapCellConnector>();
    List<GlobalMapCellConnector> _waysList = new List<GlobalMapCellConnector>();

    //    public float OffsetSector;
    private GalaxyData _data;
    private readonly List<EnemyGlobalMapMoverObjet> _enemiesObjects = new List<EnemyGlobalMapMoverObjet>();
    private bool _isEnable = true;
    private GlobalMapCellObject _lastNearObject;
    private SectorGlobalMapInfo _lastSelectedSector;

    private readonly Dictionary<GlobalMapCell, GlobalMapCellObject> _logicToVisualObjects =
        new Dictionary<GlobalMapCell, GlobalMapCellObject>();

    private float _mapPressedDownTime;
    private MapWindow _mapWindow;
    private Action<GlobalMapCellObject> CallbackNearObjec;
    public GlobalMapCellObject CellPrefab;
    public Transform ConnectionsContainer;
    public GlobalMapCellConnector GlobalMapCellBorderPrefab;
    public GlobalMapCellConnector GlobalMapCellConnectorPrefab;
    public GlobalMapCellConnector GlobalMapCellWayPrefab;
    private bool isBlock = false;
    private bool isInited;
    public GlobalMapMoverObject MapMoverObject;
    private Vector3 max;
    private Vector3 min;
    public Transform MovingArmyContainer;
    private GlobalMapCellObject myCEll;
    public float OffsetCell;
    public Transform PointsContainer;
    public Transform SectorsContainer;
    public Transform WaysContainer;

    private bool IsEnbale
    {
        get => _isEnable;
        set
        {
            _isEnable = value;
            CamerasController.Instance.GlobalMapCamera.Enable(_isEnable);
        }
    }


    public void SingleInit(GalaxyData data, MapWindow mapWindow, Action<GlobalMapCellObject> CallbackNearObjec)
    {
        if (isInited)
            return;
        _waysList.Clear();
        _logicToVisualObjects.Clear();
        SectorsContainer.ClearTransform();
        this.CallbackNearObjec = CallbackNearObjec;
        _mapWindow = mapWindow;
        isInited = true;
        _data = data;
        _data.GalaxyEnemiesArmyController.OnAddMovingArmy += OnAddMovingArmy;
        _allCells = new GlobalMapCellObject[data.SizeX, data.SizeZ];
        min = Vector3.zero;
        max = new Vector3(OffsetCell * data.SizeX, 0, OffsetCell * data.SizeZ);
        _data.OnWayDelete += OnWayDelete;
        DrawSectors(_data);
        var startCell = DrawCells(data);
        for (var i = 0; i < 22; i++)
        {
            var con = DataBaseController.GetItem(GlobalMapCellConnectorPrefab);
            _connectors.Add(con);
            con.transform.SetParent(ConnectionsContainer);
            con.gameObject.SetActive(false);
        }
var usedCells = new HashSet<GlobalMapCell>();
        if (startCell != null)
            RecursuveDrawWays(data, startCell, usedCells);
        SetBorders();
    }

    private void OnWayDelete(int id1, int id2)
    {                                                                
        Debug.LogError($"Tru delete id1:{id1}  id2:{id2}");
        foreach (var connector in _waysList)
        {
            if ((connector.FromId == id1 && connector.ToId == id2) || (connector.FromId == id2 && connector.ToId == id1))
            {
                connector.DestroyWay();
                return;
            }
        }
        Debug.LogError($"Error delted  id1:{id1}  id2:{id2}");
    }

    private void OnAddMovingArmy(MovingArmy arg1, bool arg2)
    {
        if (arg2)
        {
            var army = DataBaseController.GetItem(DataBaseController.Instance.DataStructPrefabs.MovingArmyObject);
            army.transform.SetParent(MovingArmyContainer);
            _enemiesObjects.Add(army);
            var start = GetCellObjectByCell(arg1.CurCell);
            army.Init(this, start, arg1);
            // CamerasController.Instance.SetCameraTo(start.ModifiedPosition);
        }
        else
        {
            var destroyedArmy = _enemiesObjects.FirstOrDefault(x => x.Owner == arg1);
            if (destroyedArmy != null)
            {
                _enemiesObjects.Remove(destroyedArmy);
                Destroy(destroyedArmy.gameObject);
            }
            else
            {
                Debug.LogError("can't find destroyed moving army");
            }
        }
    }

    public void ClearAll()
    {
        isInited = false;
        Dispsoe();
        CallbackNearObjec = null;
        _lastNearObject = null;
        _lastSelectedSector = null;
        SectorsContainer.ClearTransform();
        PointsContainer.ClearTransform();
        ConnectionsContainer.ClearTransform();
        WaysContainer.ClearTransform();
        _cellsWaysObjects.Clear();
        _allSectros.Clear();
        _connectors.Clear();
        _allCells = new GlobalMapCellObject[0, 0];
        _data.OnWayDelete -= OnWayDelete;
        _data = null;
    }

    private void DrawSectors(GalaxyData data)
    {
        foreach (var sector in data.AllSectors)
        {
            var sectorPlace =
                DataBaseController.GetItem(DataBaseController.Instance.DataStructPrefabs.SectorGlobalMapInfo);
            sectorPlace.transform.SetParent(SectorsContainer);
            sectorPlace.Init(sector, data, OffsetCell);
            sectorPlace.name = $"Sector {sector.Id}";
            _allSectros.Add(sectorPlace);
        }
    }

    private GlobalMapCell DrawCells(GalaxyData data)
    {
        var allCells2 = data.AllCells();
#if UNITY_EDITOR
        if (allCells2.Length < 10) Debug.LogError("MAP HAVE NO CELLS!!!");

#endif
        GlobalMapCell startCell = null;
        for (var i = 0; i < data.SizeX; i++)
            for (var j = 0; j < GalaxyData.VERTICAL_COUNT * data.SizeOfSector - 1; j++)
            {
                var cell = allCells2[i, j];
                if (cell == null) continue;

                if (!(cell is GlobalMapNothing))
                {
                    if (cell is StartGlobalCell) startCell = cell;
                    var v = new Vector3(OffsetCell * i, 0, OffsetCell * j);
                    var cellObj = DataBaseController.GetItem(CellPrefab);
                    cellObj.transform.SetParent(PointsContainer, true);
                    cellObj.transform.position = v;
                    cellObj.Init(cell, OffsetCell);
                    _logicToVisualObjects.Add(cell, cellObj);
                    cellObj.Cell.OnDestoyedCell += OnDestoyedCell;
                    _allCells[i, j] = cellObj;
                }
            }

        return startCell;
    }

    private void OnDestoyedCell(GlobalMapCell cell)
    {
        var waysToDestroy = _cellsWaysObjects[cell];
        foreach (var connector in waysToDestroy) connector.DestroyWay();
        cell.OnDestoyedCell -= OnDestoyedCell;
    }

    private void RecursuveDrawWays(GalaxyData sector, GlobalMapCell currentCell, HashSet<GlobalMapCell> usedCells)
    {
        if (usedCells.Contains(currentCell)) return;

        usedCells.Add(currentCell);
        var getAllways = currentCell.GetCurrentPosibleWays();
        foreach (var target in getAllways)
        {
            DrawWays(target, currentCell);
            RecursuveDrawWays(sector, target, usedCells);
        }
    }

    private void DrawWays(GlobalMapCell target, GlobalMapCell currentCell)
    {
        var c1 = _allCells[currentCell.indX, currentCell.indZ];
        var c2 = _allCells[target.indX, target.indZ];
        if (c1 != null && c2 != null)
        {
            var obj = DataBaseController.GetItem(GlobalMapCellWayPrefab);
            obj.gameObject.transform.SetParent(WaysContainer);
            obj.Init(c1, c2);
            AddWayToCell(target, obj);
            AddWayToCell(currentCell, obj);
        }
    }

    private void AddWayToCell(GlobalMapCell target, GlobalMapCellConnector connector)
    {
        List<GlobalMapCellConnector> list;
        if (!_cellsWaysObjects.ContainsKey(target))
        {
            list = new List<GlobalMapCellConnector>();
            _cellsWaysObjects.Add(target, list);
        }
        else
        {
            list = _cellsWaysObjects[target];
        }

        list.Add(connector);
        _waysList.Add(connector);
    }

    public void Dispsoe()
    {
        for (var i = 0; i < _data.SizeX; i++)
            for (var j = 0; j < GalaxyData.VERTICAL_COUNT * _data.SizeOfSector - 1; j++)
            {
                var cell = _allCells[i, j];
                if (cell != null)
                    cell.Cell.OnDestoyedCell -= OnDestoyedCell;
            }

        foreach (var moverObject in _enemiesObjects) DestroyImmediate(moverObject.gameObject);
        _data.GalaxyEnemiesArmyController.OnAddMovingArmy -= OnAddMovingArmy;
        _enemiesObjects.Clear();
    }

    public void SingleReset()
    {
        var player = MainController.Instance.MainPlayer;
        SingleReset(player.MapData.CurrentCell, player.MapData.ConnectedCellsToCurrent());
    }

    public void SingleReset(GlobalMapCell currentCell, HashSet<GlobalMapCell> posibleWays)
    {
        if (_data == null) return;
        //        var cells = _data.AllCells();
        for (var i = 0; i < _data.SizeX; i++)
            for (var j = 0; j < _data.SizeZ; j++)
            {
                var cell = _allCells[i, j];
                if (cell != null)
                {
                    var iamhere = cell.Cell == currentCell;
                    if (iamhere) myCEll = cell;
                    cell.SetIAmHere(iamhere);
                }
            }

        MapMoverObject.Init(myCEll);
        var connectd = 0;
        if (myCEll != null)
            foreach (var globalMapCell in posibleWays)
            {
                var canDraw = !(globalMapCell is GlobalMapNothing) && !globalMapCell.IsDestroyed;
                if (canDraw) DrawConnecttion(myCEll, globalMapCell, ref connectd);
            }
    }

    private void DrawConnecttion(GlobalMapCellObject myCEll, GlobalMapCell globalMapCell, ref int connectd)
    {
        for (var i = 0; i < _data.SizeX; i++)
            for (var j = 0; j < _data.SizeZ; j++)
            {
                var cell = _allCells[i, j];
                if (cell != null)
                {
                    var toConnect = cell.Cell == globalMapCell;
                    if (toConnect)
                    {
                        var c = _connectors[connectd];
                        connectd++;
                        //                        Debug.Log("Draw connector " + connectd);
                        SetConnectionObject(myCEll, cell, c);
                    }
                }
            }

        for (var i = connectd; i < 8; i++)
        {
            var c = _connectors[i];
            c.gameObject.SetActive(false);
        }
    }

    private void SetConnectionObject(GlobalMapCellObject myCEll, GlobalMapCellObject target,
        GlobalMapCellConnector connector)
    {
        connector.Init(myCEll, target);
    }

    public void Open()
    {
        IsEnbale = true;
        CamerasController.Instance.OpenGlobalCamera();
    }

    private void SetBorders()
    {
        float offsetBorders = 10;
        var offset = new Vector3(offsetBorders, 0, offsetBorders);
        min = min - offset;
        max = max - offset;
        CamerasController.Instance.GlobalMapCamera.InitBorders(min, max);
    }

    public void Close()
    {
        IsEnbale = false;
        gameObject.SetActive(false);
        CamerasController.Instance.CloseGlobalCamera();
    }


    public void Clicked(Vector3 pos, bool left)
    {
        if (!IsEnbale) return;
        if (left)
        {
            var isOverUI = EventSystem.current.IsPointerOverGameObject();
            if (isOverUI) return;

            var ray = GetPointByClick(pos);
            if (ray.HasValue)
            {
                float dist;
                var closeObject = ClosestObject(ray.Value, out dist);
                if (closeObject != null) _mapWindow.ClickCell(closeObject.Cell);
            }
        }
    }

    private void LateUpdate()
    {
        if (!IsEnbale || !isInited) return;

        if (Input.GetMouseButtonDown(0) && !EventSystem.current.IsPointerOverGameObject())
        {
            _mapPressedDownTime = Time.time;
            return;
        }

        if (Input.GetMouseButtonUp(0) && Time.time - _mapPressedDownTime < 0.5f &&
            !EventSystem.current.IsPointerOverGameObject())
        {
            Clicked(Input.mousePosition, true);
            return;
        }

        var ray = GetPointByClick(Input.mousePosition);
        UpdateClosetsSector(ray);
        UpdateClosest(ray);
    }

    private void UpdateClosetsSector(Vector3? point)
    {
        if (point.HasValue)
        {
            var secot = ClosestSector(point.Value, out var dist);
            if (secot != null)
            {
                //                Debug.LogError($"closest {secot.transform.position}   point:{point}  name:{secot.name}");
            }

            if (secot != _lastSelectedSector)
            {
                if (_lastSelectedSector != null) _lastSelectedSector.UnSelect();
                _lastSelectedSector = secot;
                _lastSelectedSector.Select();
            }
        }
    }

    private void UpdateClosest(Vector3? ray)
    {
        if (ray.HasValue)
        {
            float dist;
            var nearObject = ClosestObject(ray.Value, out dist);
            if (nearObject != null)
                //                Debug.Log("dist " + Mathf.Sqrt(dist) + "  " + nearObject.Cell.InfoOpen);
                if (dist < 13)
                {
                    SetClosetsObject(nearObject);
                    CallbackNearObjec(nearObject);
                    return;
                }
        }

        SetClosetsObject(null);
        CallbackNearObjec(null);
    }

    private void SetClosetsObject(GlobalMapCellObject nearObject)
    {
        if (_lastNearObject != null) _lastNearObject.UnSelected();

        _lastNearObject = nearObject;

        if (_lastNearObject != null)
            _lastNearObject.Selected();
    }

    [CanBeNull]
    private GlobalMapCellObject ClosestObject(Vector3 pos, out float dist)
    {
        var vv = float.MaxValue;
        var xIndex = (int)((pos.x + OffsetCell / 2f) / OffsetCell);
        var zIndex = (int)((pos.z + OffsetCell / 2f) / OffsetCell);
        if (xIndex >= 0 && xIndex < _data.SizeX && zIndex >= 0 && zIndex < _data.SizeZ)
        {
            var a = _allCells[xIndex, zIndex];
            if (a != null)
            {
                dist = (a.transform.position - pos).sqrMagnitude;
                return a;
            }
        }

        dist = 0f;
        return null;
    }

    private SectorGlobalMapInfo ClosestSector(Vector3 pos, out float dist)
    {
        var startDist = float.MaxValue;
        dist = 0f;
        SectorGlobalMapInfo secotr = null;
        foreach (var allSectro in _allSectros)
        {
            dist = (allSectro.transform.position - pos).sqrMagnitude;
            if (dist < startDist)
            {
                //                Debug.LogError($"dist to secv {dist}   name:{allSectro.name}");
                startDist = dist;
                secotr = allSectro;
            }
        }

        return secotr;
    }

    private Vector3? GetPointByClick(Vector3 pos)
    {
        if (CamerasController.Instance.GlobalMapCamera == null) return null;
        var ray = CamerasController.Instance.GlobalMapCamera.ScreenPointToRay(pos);
        RaycastHit hit;
        if (Physics.Raycast(ray, out hit, 9999999, 1)) return hit.point;
        return null;
    }

    public void SetCameraHome()
    {
        if (myCEll != null) CamerasController.Instance.SetCameraTo(myCEll.ModifiedPosition);
    }

    public void SetCameraToCellHome(GlobalMapCell cell)
    {
        var cellToNavigate = GetCellObjectByCell(cell);
        if (cellToNavigate != null) CamerasController.Instance.SetCameraTo(cellToNavigate.ModifiedPosition);
    }

    [CanBeNull]
    public GlobalMapCellObject GetCellObjectByCell(GlobalMapCell cell)
    {
        if (_logicToVisualObjects.TryGetValue(cell, out var cellObj)) return cellObj;
        Debug.LogError($"Can't find cell {cell}");
        return null;
    }

    public void UnBlock()
    {
        IsEnbale = true;
        SetCameraHome();
    }

    public void Block()
    {
        IsEnbale = false;
    }

    public void MoveToCell(GlobalMapCell target, Action callback)
    {
        MainController.Instance.MainPlayer.SaveGame();
        Block();
        var targetCell = GetCellObjectByCell(target);

        var shallChange2 = WindowManager.Instance.WindowSubCanvas.interactable;
        var shallChange = WindowManager.Instance.WindowMainCanvas.interactable;
        if (shallChange)
            WindowManager.Instance.WindowMainCanvas.interactable = false;
        if (shallChange2)
            WindowManager.Instance.WindowSubCanvas.interactable = false;

        bool isMainReady = false, isCallback = false, isEnemiesReady = false;

        void CheckIsAllReady()
        {
            if (isCallback) return;
            if (isMainReady)
            {
                isCallback = true;
                callback();
            }
        }

        if (targetCell != null)
        {
            var timeToMove = MapMoverObject.MoveTo(targetCell, () =>
            {
                AfterAction(shallChange, shallChange2);
                isMainReady = true;
                CheckIsAllReady();
                SingleReset();
                CamerasController.Instance.SetCameraTo(targetCell.ModifiedPosition);
                Debug.Log(
                    $"My object come to: {targetCell.Cell}.   CurMovingArmy:{targetCell.Cell.CurMovingArmy != null}");
            });
            MoveEnemies(() =>
            {
                isEnemiesReady = true;
                //                CheckIsAllReady();
            }, target, timeToMove);
        }
        else
        {
            Debug.LogError("can't find object cell by target cell");
            AfterAction(shallChange, shallChange2);
        }
    }

    // private void MainObjectMoveTo(Vector3 obj)
    // {
    //     CamerasController.Instance.SetCameraTo(obj);
    // }

    private void MoveEnemies(Action callback, GlobalMapCell playersCell, float timeToMove)
    {
        var completed = 0;
        var targetCallbacks = 0;
        var isCallbackComlete = false;

        void CheckIsAllComplete()
        {
            if (isCallbackComlete) return;
            if (completed >= targetCallbacks)
            {
                isCallbackComlete = true;
                callback();
            }
        }

        var objectsCels = new Dictionary<GlobalMapCell, EnemyGlobalMapMoverObjet>();
        foreach (var globalMapMoverObject in _enemiesObjects)
        {
            var place = globalMapMoverObject.FindPlace(playersCell);
            if (place != null && !objectsCels.ContainsKey(place))
                objectsCels.Add(place, globalMapMoverObject);
        }

        foreach (var obj in objectsCels)
            if (FindAndGo(timeToMove, obj.Value, obj.Key, () =>
            {
                completed++;
                CheckIsAllComplete();
            }))
                targetCallbacks++;

        if (targetCallbacks == 0)
        {
            isCallbackComlete = true;
            callback();
        }
    }

    private bool FindAndGo(float timeToMove, EnemyGlobalMapMoverObjet obj, GlobalMapCell cell, Action callback)
    {
        if (obj.AndGo(callback, cell, timeToMove)) return true;

        return false;
    }

    private void AfterAction(bool shallChange, bool shallChange2)
    {
        if (shallChange)
            WindowManager.Instance.WindowMainCanvas.interactable = true;
        if (shallChange2)
            WindowManager.Instance.WindowSubCanvas.interactable = true;
        UnBlock();
    }
}