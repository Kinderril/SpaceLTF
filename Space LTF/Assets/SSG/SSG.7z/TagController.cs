﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


public class TagController
{
    public const string OBJECT_MOVER_TAG = "Ship";
    public const string BULLET_TAG = "Bullet";
}

