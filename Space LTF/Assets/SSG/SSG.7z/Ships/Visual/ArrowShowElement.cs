﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;


public  class ArrowShowElement : MonoBehaviour
{
  public GameObject GO1;
  public GameObject GO2;
}

