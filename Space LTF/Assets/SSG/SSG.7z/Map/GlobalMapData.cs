﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class GlobalMapData
{
    GalaxyData[] _sectors;
    GalaxyData _curSector;


}

