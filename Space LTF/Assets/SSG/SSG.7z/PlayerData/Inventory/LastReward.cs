﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class LastReward
{
    public int Money;
    public List<WeaponInv> Weapons = new List<WeaponInv>();
    public List<BaseModulInv> Moduls = new List<BaseModulInv>();
}

