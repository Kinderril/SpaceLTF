﻿public static class LocalizationTutorial
{


    public static string GetKey(string id)
    {
        return Namings.Tag(id);

    }
}
